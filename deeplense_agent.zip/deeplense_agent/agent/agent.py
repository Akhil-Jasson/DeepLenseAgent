"""
DeepLenseSim Pydantic AI Agent

Architecture decisions
──────────────────────
1. **Pydantic AI** is chosen over Orchestral AI because:
   - Native first-class Pydantic model support for structured tool I/O
   - Built-in dependency injection via RunContext (clean separation of concerns)
   - Strong typing throughout; every tool input/output is validated at runtime
   - The "result_type" feature gives us a validated AgentResponse as the final output

2. **Human-in-the-loop (HITL)** is implemented as a synchronous pause:
   - The agent calls ask_clarification() to build ClarificationQuestion objects
   - The CLI runner (main.py) inspects the agent's response; if clarification
     questions are present it prompts the user and re-runs the agent with answers
     appended to the conversation.
   - For non-interactive contexts (API calls), questions can be skipped and
     defaults are used instead.

3. **Tool graph** (rough call ordering):
   list_available_models → get_model_details → ask_clarification (×N)
       → validate_simulation_params → run_batch_simulation → summarise_results

4. **Supported models**: Model_I and Model_II are fully featured by default;
   all four can be requested by the user.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from pydantic_ai import Agent, RunContext
from pydantic_ai.models.groq import GroqModel

from ..models import (
    AgentResponse,
    BatchSimulationResult,
    ClarificationQuestion,
    ModelConfig,
    SimulationRequest,
    SubstructureType,
)
from .tools import (
    ask_clarification,
    get_model_details,
    list_available_models,
    run_batch_simulation,
    run_simulation,
    summarise_results,
    validate_simulation_params,
)

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """\
You are DeepLenseSim Agent, an expert astrophysics simulation assistant specialising in
strong gravitational lensing simulations for dark matter substructure research.

You wrap the DeepLenseSim pipeline (mwt5345/DeepLenseSim) which uses lenstronomy to
produce synthetic lensing images across four telescope configurations:

  • Model_I   – Gaussian PSF, idealized noise (SNR~25)
  • Model_II  – Euclid VIS instrument
  • Model_III – HST ACS/WFC
  • Model_IV  – Euclid VIS with wide redshift priors

Each model supports three dark matter substructure classes:
  • no_sub  – smooth SIE lens (no substructure)
  • cdm     – Cold Dark Matter (NFW sub-halos)
  • axion   – Ultra-light axion dark matter (vortex substructure)

WORKFLOW YOU MUST FOLLOW
────────────────────────
1. Parse the user's natural language request, extracting any mentioned parameters
   (model, substructure type, number of images, redshifts, Einstein radius, etc.).

2. ALWAYS call list_available_models first to orient yourself.

3. Identify missing or ambiguous parameters.  For EACH missing critical parameter
   call ask_clarification to construct a structured question.  Critical parameters:
     - model config (which telescope/noise setup)
     - substructure_type (no_sub / cdm / axion)
     - num_images (how many images to generate)
   Optional (use defaults if unspecified): z_lens, z_source, theta_E, noise.

4. Collect clarifications (the human's answers will be provided in a follow-up turn).

5. Once all critical parameters are resolved:
   a) call validate_simulation_params to confirm no Pydantic errors
   b) call run_batch_simulation with the validated parameters
   c) call summarise_results and return the AgentResponse

6. Populate the AgentResponse with:
   - clarification_questions (if still pending)
   - resolved_request (the finalised SimulationRequest)
   - batch_result (if simulation ran)
   - agent_explanation (plain-English account of what was simulated)

IMPORTANT RULES
───────────────
• Never invent parameter values; use physics-motivated defaults from get_model_details.
• If the user asks for a physically unrealistic configuration (e.g., source behind lens
  in redshift), flag it clearly and suggest a corrected value.
• Always explain your reasoning in agent_explanation.
• Prefer run_batch_simulation over multiple run_simulation calls for efficiency.
• Default to Model_I for first-time / unspecified requests — it is the most interpretable.
"""


# ---------------------------------------------------------------------------
# Dependency injection container
# ---------------------------------------------------------------------------


@dataclass
class AgentDeps:
    """Runtime dependencies injected into every tool call via RunContext."""

    output_dir: Path = field(default_factory=lambda: Path("outputs"))
    api_key: Optional[str] = field(default=None)
    interactive: bool = field(default=True)
    max_clarification_rounds: int = field(default=2)


# ---------------------------------------------------------------------------
# Agent construction
# ---------------------------------------------------------------------------


def build_agent(model_name: str = "llama-3.3-70b-versatile") -> Agent:
    """Construct and return the configured Pydantic AI agent."""

    agent: Agent[AgentDeps, AgentResponse] = Agent(
        model=GroqModel(model_name),
        deps_type=AgentDeps,
        result_type=AgentResponse,
        system_prompt=SYSTEM_PROMPT,
    )

    # ── Register tools ────────────────────────────────────────────────────────

    @agent.tool_plain
    def tool_list_available_models() -> dict:
        """
        Return all supported Model configurations (Model_I–IV) and
        substructure types (no_sub, cdm, axion) with descriptions.
        Always call this first.
        """
        return list_available_models()

    @agent.tool_plain
    def tool_get_model_details(model_name: str) -> dict:
        """
        Get detailed observation config and default parameter priors for a
        specific Model configuration (e.g., "Model_I").

        Args:
            model_name: One of "Model_I", "Model_II", "Model_III", "Model_IV".
        """
        return get_model_details(model_name)

    @agent.tool_plain
    def tool_validate_simulation_params(params: dict) -> dict:
        """
        Validate a parameter dictionary against the SimulationRequest Pydantic model.
        Returns {"valid": True} or {"valid": False, "errors": [...]}.

        Args:
            params: Dict containing simulation parameters. Must include at minimum
                    "model" and "substructure_type".
        """
        return validate_simulation_params(params)

    @agent.tool
    def tool_run_simulation(ctx: RunContext[AgentDeps], params: dict) -> dict:
        """
        Execute a SINGLE lensing image simulation.
        Use this only for one-off images; prefer tool_run_batch_simulation for
        multiple images.

        Args:
            params: Validated simulation parameter dict.
        """
        return run_simulation(params, output_dir=str(ctx.deps.output_dir))

    @agent.tool
    def tool_run_batch_simulation(
        ctx: RunContext[AgentDeps],
        models: list[str],
        substructure_types: list[str],
        num_images_per_class: int = 5,
        lens_params: Optional[dict] = None,
        source_params: Optional[dict] = None,
        substructure_params: Optional[dict] = None,
        random_seed: Optional[int] = None,
        add_noise: bool = True,
    ) -> dict:
        """
        Execute a BATCH of lensing image simulations covering one or more
        Model configurations and substructure types.

        Args:
            models: List of model names, e.g. ["Model_I", "Model_II"].
            substructure_types: List of substructure class names, e.g. ["no_sub", "cdm"].
            num_images_per_class: Images per (model × substructure) combination.
            lens_params: Optional overrides for lens galaxy parameters (dict).
            source_params: Optional overrides for source galaxy parameters (dict).
            substructure_params: Optional overrides for substructure parameters (dict).
            random_seed: Starting seed for reproducibility.
            add_noise: Whether to add detector noise.
        """
        return run_batch_simulation(
            models=models,
            substructure_types=substructure_types,
            num_images_per_class=num_images_per_class,
            lens_params=lens_params,
            source_params=source_params,
            substructure_params=substructure_params,
            random_seed=random_seed,
            add_noise=add_noise,
            output_dir=str(ctx.deps.output_dir),
        )

    @agent.tool_plain
    def tool_ask_clarification(
        question: str,
        field_name: str,
        current_value: Optional[str] = None,
        suggested_options: Optional[list[str]] = None,
        is_required: bool = False,
    ) -> dict:
        """
        Construct a structured clarification question to ask the human user.
        Call this for EACH ambiguous or missing critical parameter BEFORE running
        any simulation.

        Args:
            question: The question text to display to the user.
            field_name: The simulation parameter name being clarified.
            current_value: The current default or inferred value (if any).
            suggested_options: List of valid options to show the user.
            is_required: True if the simulation cannot proceed without this parameter.
        """
        cq = ask_clarification(
            question=question,
            field_name=field_name,
            current_value=current_value,
            suggested_options=suggested_options,
            is_required=is_required,
        )
        return cq.model_dump()

    @agent.tool_plain
    def tool_summarise_results(batch_results: dict) -> str:
        """
        Generate a concise human-readable summary of a completed batch simulation.

        Args:
            batch_results: The dict returned by tool_run_batch_simulation.
        """
        return summarise_results(batch_results)

    return agent


# Singleton agent (lazy initialised on first use)
_agent: Optional[Agent] = None


def get_agent() -> Agent:
    global _agent
    if _agent is None:
        _agent = build_agent()
    return _agent
