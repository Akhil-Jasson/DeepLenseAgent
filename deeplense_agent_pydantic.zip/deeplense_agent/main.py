"""
DeepLenseSim Agent — Interactive CLI

Usage
─────
    # Interactive mode (full HITL loop):
    python -m deeplense_agent.main

    # One-shot mode (skip clarification, use defaults):
    python -m deeplense_agent.main --prompt "Generate 3 CDM images with HST settings"

    # Headless / CI mode:
    python -m deeplense_agent.main --no-interactive \\
        --prompt "Model_I, axion substructure, 2 images, z_lens=0.5, z_source=1.5"

    # Custom output directory:
    python -m deeplense_agent.main --output-dir ./my_lensing_data

Architecture of the HITL loop
──────────────────────────────

    ┌──────────────────────────────────────────────────┐
    │   User types natural-language prompt             │
    └──────────────────┬───────────────────────────────┘
                       │
                       ▼
    ┌──────────────────────────────────────────────────┐
    │   Agent parses prompt → identifies missing       │
    │   parameters → calls ask_clarification() for     │
    │   each ambiguous field                           │
    └──────────────────┬───────────────────────────────┘
                       │  clarification_questions list
                       ▼
    ┌──────────────────────────────────────────────────┐
    │   CLI presents questions to human interactively  │
    │   (up to max_clarification_rounds rounds)        │
    └──────────────────┬───────────────────────────────┘
                       │  answers appended to conversation
                       ▼
    ┌──────────────────────────────────────────────────┐
    │   Agent re-runs with answers → validates params  │
    │   → calls run_batch_simulation → summarises      │
    └──────────────────┬───────────────────────────────┘
                       │
                       ▼
    ┌──────────────────────────────────────────────────┐
    │   CLI prints summary + image paths + metadata    │
    └──────────────────────────────────────────────────┘
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
from pathlib import Path
from typing import Optional

# Ensure the parent directory is on sys.path so `deeplense_agent` is importable
# whether you run as `python -m main` (from inside) or `python -m deeplense_agent.main` (from outside)
sys.path.insert(0, str(Path(__file__).parent.parent))

logging.basicConfig(
    level=logging.WARNING,
    format="%(levelname)s  %(name)s — %(message)s",
)
logger = logging.getLogger("deeplense_agent.main")

# Rich is optional; fall back to plain print
try:
    from rich import print as rprint
    from rich.console import Console
    from rich.panel import Panel
    from rich.prompt import Prompt
    from rich.table import Table

    console = Console()
    _HAS_RICH = True
except ImportError:
    _HAS_RICH = False
    rprint = print  # type: ignore


def _print_banner() -> None:
    banner = """
╔══════════════════════════════════════════════════════════════════╗
║          DeepLenseSim Agent  •  Strong Gravitational Lensing     ║
║   ML4Sci / DeepLense  •  Pydantic AI  •  Groq + lenstronomy    ║
╚══════════════════════════════════════════════════════════════════╝
"""
    rprint(banner)


def _ask_user(question: str, options: list[str], current: Optional[str]) -> str:
    """Present a clarification question and collect user input."""
    print(f"\n  ❓ {question}")
    if current is not None:
        print(f"     (default: {current})")
    if options:
        for i, opt in enumerate(options, 1):
            print(f"     [{i}] {opt}")
        raw = input("     Your choice (number or value, Enter = default): ").strip()
        if not raw and current is not None:
            return str(current)
        # Accept numeric shortcut
        if raw.isdigit() and 1 <= int(raw) <= len(options):
            return options[int(raw) - 1]
        return raw or str(current or "")
    else:
        raw = input(f"     Answer (Enter = {current!r}): ").strip()
        return raw or str(current or "")


def _format_answer_block(questions_and_answers: list[tuple[str, str]]) -> str:
    """Format Q&A pairs into a follow-up message for the agent."""
    lines = ["Here are my answers to your clarifying questions:\n"]
    for q, a in questions_and_answers:
        lines.append(f"• {q}  → {a}")
    return "\n".join(lines)


def _display_result(result_data: dict) -> None:
    """Pretty-print the simulation result summary."""
    print("\n" + "─" * 70)
    if result_data.get("success"):
        print("✅  Simulation completed successfully!")
    else:
        print(f"❌  Simulation failed: {result_data.get('error_message', 'unknown error')}")
        return

    if br := result_data.get("batch_result"):
        summary = br.get("summary", {})
        print(f"\n   Total images:    {br.get('total_succeeded')}")
        if "by_model" in summary:
            print(f"   By model:        {summary['by_model']}")
        if "by_substructure" in summary:
            print(f"   By substructure: {summary['by_substructure']}")
        if "mean_snr" in summary:
            print(f"   Mean SNR:        {summary['mean_snr']:.1f} ± {summary.get('std_snr', 0):.1f}")
        print(f"   Output dir:      {br.get('output_directory', 'outputs/')}")

    if exp := result_data.get("agent_explanation"):
        print(f"\n💬  Agent explanation:\n   {exp}")

    print("─" * 70 + "\n")


async def run_agent_loop(
    prompt: str,
    output_dir: Path,
    interactive: bool = True,
    max_rounds: int = 2,
) -> dict:
    """
    Run the agent with HITL clarification loop.

    Returns the final AgentResponse as a dict.
    """
    from deeplense_agent.agent.agent import AgentDeps, build_agent
    from deeplense_agent.models import AgentResponse

    agent = build_agent()
    deps = AgentDeps(
        output_dir=output_dir,
        interactive=interactive,
        max_clarification_rounds=max_rounds,
    )

    current_prompt = prompt
    final_response: Optional[AgentResponse] = None

    for round_num in range(max_rounds + 1):
        print(f"\n🔭  Agent is processing your request (round {round_num + 1})…")

        result = await agent.run(current_prompt, deps=deps)
        raw = result.data

        # result.data may be a string (LLM reply) or an AgentResponse dict
        if isinstance(raw, AgentResponse):
            response = raw
        elif isinstance(raw, dict):
            try:
                response = AgentResponse(**raw)
            except Exception:
                # LLM returned a plain dict that doesn't match — wrap it
                response = AgentResponse(
                    user_prompt=current_prompt,
                    agent_explanation=str(raw),
                    success=True,
                )
        else:
            # Plain string response from the LLM
            response = AgentResponse(
                user_prompt=current_prompt,
                agent_explanation=str(raw),
                success=True,
            )

        # ── Check for pending clarification questions ──────────────────────
        pending = [
            q for q in response.clarification_questions
            if q.current_value is None or q.is_required
        ] if response.clarification_questions else []

        if not pending or not interactive or round_num >= max_rounds:
            final_response = response
            break

        # ── Present questions to the human ─────────────────────────────────
        print(f"\n📋  The agent has {len(pending)} clarifying question(s):\n")
        qa_pairs: list[tuple[str, str]] = []
        for cq in pending:
            answer = _ask_user(
                question=cq.question,
                options=cq.suggested_options,
                current=str(cq.current_value) if cq.current_value is not None else None,
            )
            qa_pairs.append((cq.question, answer))

        # Append answers to the conversation for the next round
        answers_block = _format_answer_block(qa_pairs)
        current_prompt = answers_block
        # (In a real multi-turn setup we would pass message history; here we
        #  summarise answers into a follow-up prompt for simplicity.)

    if final_response is None:
        return {"success": False, "error_message": "Agent loop did not converge."}

    return final_response.model_dump(exclude={"batch_result"}) | {
        "batch_result": final_response.batch_result.model_dump()
        if final_response.batch_result
        else None,
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="DeepLenseSim Agent — NL-driven strong lensing simulation"
    )
    parser.add_argument(
        "--prompt",
        type=str,
        default=None,
        help="Natural language simulation request (interactive prompt if omitted)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("outputs"),
        help="Directory to save generated images (default: ./outputs)",
    )
    parser.add_argument(
        "--no-interactive",
        action="store_true",
        help="Disable human-in-the-loop clarification (use agent defaults)",
    )
    parser.add_argument(
        "--max-rounds",
        type=int,
        default=2,
        help="Maximum clarification rounds (default: 2)",
    )
    parser.add_argument(
        "--json-output",
        action="store_true",
        help="Print full JSON response to stdout instead of formatted output",
    )
    args = parser.parse_args()

    _print_banner()

    # Collect the initial prompt
    if args.prompt:
        user_prompt = args.prompt
    else:
        print("Enter your simulation request (e.g.: 'Generate 5 CDM images with HST settings'):")
        user_prompt = input("  > ").strip()
        if not user_prompt:
            print("No prompt provided. Exiting.")
            sys.exit(0)

    print(f"\n📝  Prompt: {user_prompt!r}")

    result = asyncio.run(
        run_agent_loop(
            prompt=user_prompt,
            output_dir=args.output_dir,
            interactive=not args.no_interactive,
            max_rounds=args.max_rounds,
        )
    )

    if args.json_output:
        print(json.dumps(result, indent=2, default=str))
    else:
        _display_result(result)


if __name__ == "__main__":
    main()
